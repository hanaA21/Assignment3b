package Assignments;

public class Method {
    // Instance fields
    private int instanceField1;
    private String instanceField2;

    // Static field
    private static int staticField;
    // Instance initialization blocks
    {
        System.out.println("Instance Initialization Block 1");
        // Initialization code for instanceField1 or other instance-specific tasks
    }

    {
        System.out.println("Instance Initialization Block 2");
        // Initialization code for instanceField2 or other instance-specific tasks
    }

    // Static initialization blocks
    static {
        System.out.println("Static Initialization Block 1");
        // Initialization code for staticField or other static-specific tasks
    }

    static {
        System.out.println("Static Initialization Block 2");
        // Additional initialization code for staticField or other static-specific tasks
    }

    // Constructors
    public Method() {
        System.out.println("Default Constructor");
        // Additional constructor-specific tasks
    }

    public Method(int value1, String value2) {
        this.instanceField1 = value1;
        this.instanceField2 = value2;
        System.out.println("Parameterized Constructor");
        // Additional constructor-specific tasks
    }

    // Instance methods
    public void instanceMethod1() {
        System.out.println("Instance Method 1");
        // Additional instance-specific tasks
    }

    public void instanceMethod2() {
        System.out.println("Instance Method 2");
        // Additional instance-specific tasks
    }

    // Static methods
    public static void staticMethod1() {
        System.out.println("Static Method 1");
        // Additional static-specific tasks
    }

    public static void staticMethod2() {
        System.out.println("Static Method 2");
        // Additional static-specific tasks
    }
}
