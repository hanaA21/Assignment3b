package Assignments;


public class Mainn {
    public static void main(String[] args) {
        System.out.println("Creating Object 1:");
        Method object1 = new Method();

        System.out.println("\nCreating Object 2:");
        Method object2 = new Method(42, "Hello");

        // Calling methods on the objects
        object1.instanceMethod1();
        object2.instanceMethod2();

        Method.staticMethod1();
        Method.staticMethod2();
    }

}
