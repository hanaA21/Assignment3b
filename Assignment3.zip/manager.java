package Assignments;

public class manager {
    static String firstName;
    static String lastName;
    static int salary;

    public static String getFirstName(){
        return firstName;
    }
    public static String getLastName(){
        return lastName;
    }
   public static int getSalary(){
        return salary;
   }
}
